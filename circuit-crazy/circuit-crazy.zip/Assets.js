class Assets {
    static loadAssets() {
        this.ham = loadImage("assets/ham.jpg")
        this.addNode = loadImage("assets/addCircuit.png")
        this.divNode = loadImage("assets/divCircuit.png")
        this.subNode = loadImage("assets/subCircuit.png")
        this.inputNode = loadImage("assets/input.png")
        this.outputNode = loadImage("assets/output.png")
        this.constantNode = loadImage("assets/constant.png")
        this.factorialNode = loadImage("assets/factorialCircuit.png")
        this.chooseNode = loadImage("assets/chooseCircuit.png")
        this.expNode = loadImage("assets/factorialCircuit.png")
        this.multNode = loadImage("assets/timesCircuit.png")
        this.titleBkgd = loadImage("assets/title_background.png")
        this.expNode = loadImage("assets/expCircuit.png")
    }
    static setVolume(volume) {
    }
}