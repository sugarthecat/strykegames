class InputWire{
    constructor(name, color = {r: 255, g: 255, b: 255}){
        this.name = name;
        this.color = color;
    }

}